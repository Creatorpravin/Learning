import os

import CoreCode.logger as Logger
import CoreCode.service_manager_linux_helper_functions as LinuxHelperFunctions
import Definitions.message_definitions as MessageDefinitions
import Definitions.message_code_definitions as MessageCodeDefinition
import Definitions.system_definitions as SystemDefinitions

SPACE_CHARACTER = " "
NEW_LINE_CHARACTER = "\n"

RECEIVED_SYSTEM_UPGRADE_NOTIFICATION = "Received system upgrade message"
SYSTEM_UPGRADE_SUCCESSFUL_NOTIFICATION = "System upgraded successfully"
SYSTEM_UPDATED_PACKAGE_LIST_UPDATED_SUCCESSFULLY_NOTIFICATION = "System update package list updated"
RECEIVED_SYSTEM_UPGRADE_PACKAGE_NOTIFICATION = "System upgrade package received successfully"
SYSTEM_UPGRADE_PACKAGE_INSTALLED_SUCCESSFULLY_NOTIFICATION = "System upgrade package installed successfully"
SYSTEM_UPDATED_PACKAGE_LIST_UPDATE_FAILED_NOTIFICATION = "Failed to update package list"
FAILED_TO_UPGRADE_PYTHON_DEPENDENT_MODULES_NOTIFICATION = "Failed to install CPE dependent python modules"
FAILED_TO_INSTALL_DEPENDENT_SYSTEM_UTILITES_NOTIFICATION = "Failed to install CPE dependent system utility"


FAILED_TO_RECEIVE_SYSTEM_UPGRADE_PACKAGE_NOTIFICATION = "Failed to system update  receive package"
FAILED_TO_INSTALL_SYSTEM_UPGRADE_PACKAGE_NOTIFICATION = "Failed to install system upgrade package"
FAILED_TO_RESTART_CHIEFNET_SERVICE_NOTIFICATION = "Failed to start chiefnet service"


class SystemUpgrade():
    """
    SystemUpgrade is used to upgrade system packages

    Arguments:
    response_manager:
        An instance of ResponseManager must be passed to send responses to the WebApp
    """

    def __init__(self, response_manager):
        self.__logger = Logger.get_logger(logger_name=__name__)

        self.__logger.info("SystemUpgrade initializer starts")
        
        self._response_manager = response_manager

        self.__logger.info("SystemUpgrade initializer ends")


    def system_upgrade_request_callback(self, system_upgrade_request_message):
        """
        system_upgrade_request_callback preform the upgrade process for the package with the version specified in 
        the system upgrade request message 

        Args    - System upgrade request message from server
        Returns - True  - If system upgrade process is success
                  False - If system upgrade process is failed          
        """ 
        # self._response_manager.send_response(message=system_upgrade_request_message, 
        #                                         status_code=MessageCodeDefinition.RECEIVED_SYSTEM_UPGRADED_MESSAGE,
        #                                         status_message=RECEIVED_SYSTEM_UPGRADE_NOTIFICATION)

        return self.__perform_system_upgrade(system_upgrade_request_message)


    def __perform_system_upgrade(self, system_upgrade_request_message):
        self.__logger.info("Performing system upgrade")

        if LinuxHelperFunctions.update_package_list(logger_object=self.__logger) == True:
            # self._response_manager.send_response(message=system_upgrade_request_message, 
            #                                     status_code=MessageCodeDefinition.SYSTEM_UPDATED_PACKAGE_LIST_UPDATED_SUCCESSFULLY,
            #                                     status_message=SYSTEM_UPDATED_PACKAGE_LIST_UPDATED_SUCCESSFULLY_NOTIFICATION)
            self.__logger.info(SYSTEM_UPDATED_PACKAGE_LIST_UPDATED_SUCCESSFULLY_NOTIFICATION)
        else:
            # self._response_manager.send_response(message=system_upgrade_request_message, 
            #                                     status_code=MessageCodeDefinition.SYSTEM_UPDATED_PACKAGE_LIST_UPDATE_FAILED,
            #                                     status_message=SYSTEM_UPDATED_PACKAGE_LIST_UPDATE_FAILED_NOTIFICATION)
            # self.__logger.error(SYSTEM_UPDATED_PACKAGE_LIST_UPDATE_FAILED_NOTIFICATION)

            return False

        if LinuxHelperFunctions.install_package(system_upgrade_request_message[MessageDefinitions.CONTENT_KEY][MessageDefinitions.PACKAGE_KEY], logger_object=self.__logger) == True:
            # self._response_manager.send_response(message=system_upgrade_request_message, 
            #                                     status_code=MessageCodeDefinition.SYSTEM_UPGRADE_PACKAGE_INSTALLED_SUCCESSFULLY,
            #                                     status_message=SYSTEM_UPGRADE_PACKAGE_INSTALLED_SUCCESSFULLY_NOTIFICATION)
            self.__logger.info(SYSTEM_UPGRADE_PACKAGE_INSTALLED_SUCCESSFULLY_NOTIFICATION)
        else:
            # self._response_manager.send_response(message=system_upgrade_request_message, 
            #                                     status_code=MessageCodeDefinition.FAILED_TO_INSTALL_SYSTEM_UPGRADE_PACKAGE,
            #                                     status_message=FAILED_TO_INSTALL_SYSTEM_UPGRADE_PACKAGE_NOTIFICATION)
            self.__logger.error(FAILED_TO_INSTALL_SYSTEM_UPGRADE_PACKAGE_NOTIFICATION)

            return False

        if os.path.exists(SystemDefinitions.PYTHON_REQUIREMENTS_FILE_PATH) == True:
            self.__logger.info("Installing python dependent modules for CPE")

            if LinuxHelperFunctions.execute_script(filepath=SystemDefinitions.PYTHON_UPGRADE_SCRIPT, logger_object=self.__logger) != True:
                # self._response_manager.send_response(message=system_upgrade_request_message, 
                #                                     status_code=MessageCodeDefinition.FAILED_TO_UPGRADE_PYTHON_DEPENDENT_MODULES,
                #                                     status_message=FAILED_TO_UPGRADE_PYTHON_DEPENDENT_MODULES_NOTIFICATION)
                self.__logger.error(FAILED_TO_UPGRADE_PYTHON_DEPENDENT_MODULES_NOTIFICATION)
                
                return False

        if os.path.exists(SystemDefinitions.CHIEFNET_DEPENDENT_UTILITIES_REQUIREMENT_FILE_PATH) == True:
            self.__logger.info("Installing system dependent modules for CPE")

            with open(SystemDefinitions.CHIEFNET_DEPENDENT_UTILITIES_REQUIREMENT_FILE_PATH, SystemDefinitions.FILE_READ_MODE) as network_utilities:
                package_list = network_utilities.readlines()

            for package in package_list:
                if LinuxHelperFunctions.install_package(package, logger_object=self.__logger) != True:
                    self._response_manager.send_response(message=system_upgrade_request_message, 
                                                        status_code=MessageCodeDefinition.FAILED_TO_INSTALL_DEPENDENT_SYSTEM_UTILITY,
                                                        status_message=FAILED_TO_INSTALL_DEPENDENT_SYSTEM_UTILITES_NOTIFICATION + SPACE_CHARACTER + package)
                    self.__logger.error(FAILED_TO_INSTALL_DEPENDENT_SYSTEM_UTILITES_NOTIFICATION + SPACE_CHARACTER + package )

                    return False
                else:
                    self.__logger.info("Installed - {}".format(package) )

        if LinuxHelperFunctions.start_system_service(service_name=SystemDefinitions.CHIEFNET_SERVICE, logger_object=self.__logger) == True:
            self.__logger.info(SYSTEM_UPGRADE_SUCCESSFUL_NOTIFICATION)
        else:
            self._response_manager.send_response(message=system_upgrade_request_message, 
                                                status_code=MessageCodeDefinition.FAILED_TO_RESTART_CHIEFNET_SERVICE,
                                                status_message=FAILED_TO_RESTART_CHIEFNET_SERVICE_NOTIFICATION)
            self.__logger.error(FAILED_TO_RESTART_CHIEFNET_SERVICE_NOTIFICATION)

            return False

        # self._response_manager.send_response(message=system_upgrade_request_message, 
        #                             status_code=MessageCodeDefinition.SYSTEM_UPGRADED_SUCCESSFULLY,
        #                             status_message=SYSTEM_UPGRADE_SUCCESSFUL_NOTIFICATION)
        return True
