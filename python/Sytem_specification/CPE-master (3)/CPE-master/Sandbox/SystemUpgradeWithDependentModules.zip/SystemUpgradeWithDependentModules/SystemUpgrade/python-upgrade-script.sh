#!/bin/bash

cd /home/chiefnet/ChiefNet/

RequirementFile=CPE/requirements.txt

if [ -f $RequirementFile ]; then
    activate()
    { source VirtualEnvironment/bin/activate; }
    activate

    pip install -r $RequirementFile

    # pipStatus = $?
    if [ $? == 0 ];then
        printf "pip installed success"
        deactivate
    else
        printf "pip installed failed"
        deactivate
        exit 1
    fi
fi

exit 0