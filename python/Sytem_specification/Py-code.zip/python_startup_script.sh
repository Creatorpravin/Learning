#!/bin/sh

py -m venv VirEnv

source VirEnv/bin/activate

python main.py